console.log("this is script file")

const toggleSidebar = () => {

if($('.sidebar').is(":visible")){
  /*  block display */

    $(".sidebar").css("display","none");
    $(".content").css("margin-left","0%");

}
else
{
  /* show display */

  $(".sidebar").css("display","block");
  $(".content").css("margin-left","20%");

}

};


//search operation for user

const search =() => {
  console.log("searching..."); 

 let text =$("#search-text").val();

 if(text==''){
	
$(".search-result").hide();
   
 
 }
 else{
//search
 

  //sending request
  let url=`http://localhost:8080/search/${text}`;

  fetch(url).then((response) => {
   return response.json();
   })
  .then((data) => {
	
//data

  console.log(data);

  let query=`<div class='list-group' >`;
  data.forEach((question) => {

    query+=`<a href='/user/${question.qId}/viewQuery' class='list-group-item list-group-action'> ${question.question}</a>`

  });
query +=`</div>`;

$(".search-result").html(query);
$(".search-result").show();
  });  

 
 }

};




//search operation for admin

const searchQuery =() => {
  console.log("searching..."); 

 let text =$("#search-text").val();

 if(text==''){
	
$(".search-result").hide();
   
 
 }
 else{
//search
 

  //sending request
  let url=`http://localhost:8080/search/${text}`;

  fetch(url).then((response) => {
   return response.json();
   })
  .then((data) => {
	
//data

  console.log(data);

  let query=`<div class='list-group' >`;
  data.forEach((question) => {

    query+=`<a href='/admin/${question.qId}/viewQuery' class='list-group-item list-group-action'> ${question.question}</a>`

  });
query +=`</div>`;

$(".search-result").html(query);
$(".search-result").show();
  });  

 
 }

};


