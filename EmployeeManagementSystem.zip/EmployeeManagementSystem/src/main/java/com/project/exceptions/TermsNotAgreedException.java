package com.project.exceptions;

public class TermsNotAgreedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TermsNotAgreedException(String message) {
		super(message);
	}

	
	
}
