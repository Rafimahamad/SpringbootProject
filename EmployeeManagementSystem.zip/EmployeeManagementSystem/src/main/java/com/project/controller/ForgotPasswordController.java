package com.project.controller;

import java.util.Random;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.entity.Employee;
import com.project.entity.Message;
import com.project.service.EmailService;
import com.project.service.EmployeeService;


@Controller
public class ForgotPasswordController {

	@Autowired
	private EmailService  emailService;
	
	@Autowired
	
	private EmployeeService service;
	
	private static final String MESSAGE="message";
	
	private static final String DANGER="danger";
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	static Logger log=LoggerFactory.getLogger(ForgotPasswordController.class);

	
	Random random = new Random(10000);
	
	private static final String FORGOT="forgot";
	
	@RequestMapping("/forgotPassword")
	public String forgotPassword() {
		
		return FORGOT;
		
	}
	

//	send OTP......
	@PostMapping("/sendotp")
	public String sendOtp(@RequestParam("email") String email,HttpSession session) {
		
	log.info("otp Send to this email {}",email);
		
//		generate otp of 4-digit
	
		int otp = random.nextInt(9999);
		System.out.println(otp+"----------------------------------");
		log.info("generated Otp : {}",otp);
		
		 Employee employee = this.service.getEmployeeByEmail(email);
		
		if(employee==null) {
		    session.setAttribute(MESSAGE, new Message("User does not found ! with this email id ", DANGER));
					
					return FORGOT;
				}
		else {
		//write code to send to your email
		
		String subject="OTP from DSRS";
		String message=""
				+ "<div style='border:1px solid #e2e2e2; padding:20px'>"
				+ "<h1>"
				+ "OTP is : "
				+ "<b>"+otp
				+ "</n"
				+ "</h1>"
				+ "</div>";
		String to=email;
				
		boolean sendEmail = this.emailService.sendEmail(subject, message, to);
		
		if(sendEmail) {
			
			session.setAttribute(MESSAGE, new Message("we sent 4-digit OTP to your Email", "success"));
          session.setAttribute("myOtp", otp);
         session.setAttribute("email", email);
			return "verify-otp";
			
		}
		else {
		
			session.setAttribute(MESSAGE, "check your email id");
			
			return FORGOT;
		}
		}
	}
	
	
//	verify OTP.....
	
	@PostMapping("/verify-otp")
	public String verifyotp(@RequestParam("otp") int otp,HttpSession session){
		
		int myOtp= (int) session.getAttribute("myOtp");
		
	
	if(myOtp==otp) {
		
		session.setAttribute(MESSAGE,new Message("OTP verified Successfully ", "success") );
		return "changePasswordForm";
	}
	else {
		
		session.setAttribute(MESSAGE,new Message("Incorrect OTP! ", DANGER) );
		
		return "verify-otp";
	}
	
	}

	
	@PostMapping("/changePassword")
public String changePassword(@RequestParam("newPassword") String newPassword,@RequestParam("confirmPassword") String confirmPassword,HttpSession session) {
	
		if(newPassword.equals(confirmPassword)) {
		
		String email=(String) session.getAttribute("email");
		 Employee employee = this.service.getEmployeeByEmail(email);
			
			
		
		employee.setPassword(this.bCryptPasswordEncoder.encode(newPassword));
		this.service.saveEmp(employee);
		log.info("password is changed");
	    return "redirect:/login?change=password changed Successfully...";
		}
		else {
			log.warn("password not match with the confirm password ");
			session.setAttribute(MESSAGE,new Message("Your password should be matched to confirm password ! ", DANGER) );
			return "changePasswordForm";
		}
}

	
	
	
}
