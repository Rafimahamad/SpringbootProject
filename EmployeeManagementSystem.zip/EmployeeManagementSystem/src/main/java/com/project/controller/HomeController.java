package com.project.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.project.entity.Employee;
import com.project.entity.Message;
import com.project.exceptions.TermsNotAgreedException;
import com.project.service.EmployeeService;

@Controller
public class HomeController {
    
	@Autowired
	private EmployeeService employeeService;
    
@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	

private static String SIGNUP="signUp";
private static String DLIST="dlist";
private static String MESSAGE="message";




static Logger log=LoggerFactory.getLogger(HomeController.class);

List<String>designationList=Arrays.asList("","Associate Software Engineer","Software Engineer",
		                                    "Associate Engineer Technology","Engineer Technology","lead Consultant",
		                                    "Train Engineer","Engineer IT","Associate Architect Engineer","Architect Engineer","others");

@RequestMapping("/")
public String homePage() {
	
	return "home";
}

@GetMapping("/signup")
public String signUpPage(Model m) {
	m.addAttribute("emp",new Employee());
	m.addAttribute(DLIST, designationList);
	return SIGNUP;
}

@PostMapping("/saveEmp")
public String saveEmployee(@Valid @ModelAttribute("emp") Employee emp,BindingResult result,@RequestParam("profileImage") MultipartFile file,
		  @RequestParam(value="agreement",defaultValue = "false") boolean agreement,Model m,HttpSession session) throws TermsNotAgreedException{
			
	try {
		
		if(!agreement)
		{
			throw new TermsNotAgreedException("you have not agree the terms and conditions");
		}
		
		if(result.hasErrors()) {
			m.addAttribute("emp",emp);
			m.addAttribute(DLIST, designationList);
		}
		
		if(file.isEmpty()) {
			if(emp.getGender().equals("Female")) {
				emp.setProfile("female.png");
			}
			else {
				emp.setProfile("male.png");
			}
		}
		else {
			emp.setProfile(file.getOriginalFilename());
			File saveFile=new ClassPathResource("static/img").getFile();
			Path path=Paths.get(saveFile.getAbsolutePath()+File.separator+file.getOriginalFilename());
			Files.copy(file.getInputStream(),path,StandardCopyOption.REPLACE_EXISTING);
		}
		emp.setPassword(passwordEncoder.encode(emp.getPassword()));
		emp.setRole("ROLE_USER");
		this.employeeService.registerEmp(emp);
		
		m.addAttribute("emp",new Employee());
		
		session.setAttribute(MESSAGE, new Message("Registered Successfully !","alert-success"));
		log.info("registered");
	} catch (Exception e) {
		e.printStackTrace();
		m.addAttribute("emp", emp);
		m.addAttribute(DLIST, designationList);
		log.error("exception occured");
		session.setAttribute(MESSAGE, new Message("Something went wrong !","alert-danger"));
		
	}
	

	return SIGNUP;
	
}

@GetMapping("/login")
public ModelAndView login(ModelAndView m) {
	m.setViewName("login");
	return m;
}



@GetMapping("/check")
public String checkLoginCredential(Principal p,Model m,HttpSession session) {
	String name=p.getName();
	
	try {
		Employee employeeByEmail = employeeService.getEmployeeByEmail(name);
		m.addAttribute("emp",employeeByEmail);
		if(employeeByEmail.getRole().equals("ROLE_ADMIN"))
		{
			return "redirect:/admin/index/0";
		}
		if(employeeByEmail.getRole().equals("ROLE_USER"))
		{
			return "redirect:/user/index/0";
		}
		session.setAttribute(MESSAGE, new Message("You have blocked by admin !", "danger"));

	} catch (Exception e) {
		log.error(e.getMessage());
	}
	
	
	
	return "redirect:/contactUs";
	
}



}
