package com.project.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.project.entity.Questions;
import com.project.service.QuestionService;

@Controller
public class SearchController {

	@Autowired
	private QuestionService questionService;
	

	
	@GetMapping("/search/{text}")
	public ResponseEntity<List<Questions>> search(@PathVariable("text") String text,HttpSession session)
	{
		
		try {
			
			List<Questions> list = questionService.findByQuestionContaining(text);
			
			return ResponseEntity.ok(list);
			
		  }catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	
}
