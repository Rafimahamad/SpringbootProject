package com.project.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.project.entity.Employee;
import com.project.entity.Message;
import com.project.entity.Questions;
import com.project.service.EmployeeService;
import com.project.service.QuestionService;



@Controller

@RequestMapping("/user")
public class UserController {
    
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private QuestionService questionService;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	

static Logger log=LoggerFactory.getLogger(UserController.class);

	
	private static String DLIST="dlist";
	private static String MESSAGE="message";
	private static String SUCCESS="success";
	private static String DANGER="danger";
	
	
List<String>designationList=Arrays.asList("","Associate Software Engineer","Software Engineer",
		                                    "Associate Engineer Technology","Engineer Technology","lead Consultant",
		                                    "Train Engineer","Engineer IT","Associate Architect Engineer","Architect Engineer","others");

	
	@ModelAttribute
	public void getCurrentEmployee(Model m,Principal p) {
		String name = p.getName();
		
		Employee employee = this.employeeService.getEmployeeByEmail(name);
		
		m.addAttribute("emp", employee);
		m.addAttribute("dlist", designationList);
	}
	
	
	@RequestMapping("/index/{pageNo}")
	public String dashboard(Model m,@PathVariable("pageNo") int pageNo) {
		try {
			m.addAttribute("title", "user-Dashboard");
			
			int items=5;
			Page<Questions> page=questionService.findPaginated(pageNo, items);
			List<Questions> questions=page.getContent();
			m.addAttribute("qlist", questions);
		} 
		catch (Exception e) {
			log.error(e.getMessage());
		}
		
		return "user/index";
	}
	
	
	@GetMapping("/profile")
	public String yourProfile(Model m) {

		
		return "user/profile";

	}
	
	@GetMapping("/editprofile/{id}")
	public String editProfile(@PathVariable("id") int id,Model m) {

		return "user/editprofile";

	}
	
	@PostMapping(value = "/saveprofile")
	public String registerUser(@Valid  @ModelAttribute("emp") Employee emp ,BindingResult result,@RequestParam("profileImage") MultipartFile file,
			Model m,HttpSession session) {
		
		try {

			if(result.hasErrors()) {
				log.warn("error {}",result);
				m.addAttribute("emp",emp);
				m.addAttribute(DLIST,designationList);
				
			return "user/editprofile";
				
			}
			if(!file.isEmpty()) {

				File deleteFile = new ClassPathResource("static/img").getFile();
				File file1 = new File(deleteFile, emp.getProfile());
			
				
				boolean delete = file1.delete();
				
				log.info("is old file is deleted {}",delete);


				File saveFile = new ClassPathResource("static/img").getFile();

				Path path = Paths.get(saveFile.getAbsolutePath()+File.separator+file.getOriginalFilename());

				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				emp.setProfile(file.getOriginalFilename());
				log.info("img is uploaded");

			}
			else {

				emp.setProfile(emp.getProfile());

			}
			log.info("Saved Employee {}",emp.getPassword());
			
			
			//emp.setPassword(passwordEncoder.encode(emp.getPassword()));
			
			
			 this.employeeService.saveEmp(emp);
			
			m.addAttribute("emp", new Employee());
			
			session.setAttribute(MESSAGE, new Message("updated successfilly ! ", SUCCESS));
		
	
		} catch (Exception e) {
			

			e.printStackTrace();
			m.addAttribute("emp",emp);
			m.addAttribute(DLIST,designationList);
			
			session.setAttribute(MESSAGE, new Message("some thing went wrong! "+e.getMessage(), DANGER));
		}
		
		return "redirect:/user/profile";
			
	}
	
	
	@GetMapping("/yourQueries")
	public String viewYourQueries(Model m,Principal p) {
		
         String name = p.getName();
		
		Employee employee = this.employeeService.getEmployeeByEmail(name);
		List<Questions> questions = employee.getQuestions();
		
		m.addAttribute("qlist", questions);
		
		return "user/yourQueries";
		
	}
	
	
	@RequestMapping("/settings")
	public String  settingsTab() {
		return "user/setting";

	}

	//change password

	@PostMapping("/change-Password")
	public String changePassword(@RequestParam("oldPassword") String oldPassword,@RequestParam("newPassword") String newPassword,Principal principal,HttpSession session) {
		log.info("password {}", oldPassword);
		log.info("password {}", newPassword);
		String name = principal.getName();
		Employee employee = this.employeeService.getEmployeeByEmail(name);
		
		
		
		if(this.passwordEncoder.matches(oldPassword, employee.getPassword()))
		{
			if(oldPassword.equals(newPassword)) {
				
				session.setAttribute(MESSAGE,new  Message("Set the different Password doesn't used in previously..", DANGER));
				return "redirect:/user/settings";
			}
			employee.setPassword(this.passwordEncoder.encode(newPassword));
			this.employeeService.saveEmp(employee);
			session.setAttribute(MESSAGE,  new  Message("password changed Successfully", SUCCESS));
		}

		else {
			session.setAttribute(MESSAGE,new  Message("Incorrect  Password", DANGER));
			return "redirect:/user/settings";
		}

		return "redirect:/user/index/0";
		}
	
	
}
