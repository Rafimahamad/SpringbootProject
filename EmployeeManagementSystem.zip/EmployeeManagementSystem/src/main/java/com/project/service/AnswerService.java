package com.project.service;

import com.project.entity.Answers;

public interface AnswerService {
	
	Answers getAnswerById(int aId);
	Answers saveAnswer(Answers ans);
	void deleteAnswer(Answers ans);

}
