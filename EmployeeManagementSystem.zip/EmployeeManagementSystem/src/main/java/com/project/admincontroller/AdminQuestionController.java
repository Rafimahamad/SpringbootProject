package com.project.admincontroller;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.controller.QuestionController;
import com.project.entity.Answers;
import com.project.entity.Employee;
import com.project.entity.Message;
import com.project.entity.Questions;
import com.project.service.AnswerService;
import com.project.service.EmailService;
import com.project.service.EmployeeService;
import com.project.service.QuestionService;

@Controller
@RequestMapping("/admin")
public class AdminQuestionController {

	
	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private QuestionService questionService;

	@Autowired
	private AnswerService answerService;


	@Autowired
	private EmailService emailService;

	static Logger log=LoggerFactory.getLogger(QuestionController.class);

	private static final String MESSAGE="message";

	private static final String QUERY="query";


	private static final String DELETE="you can't delete it !";

	private static final String WRONG ="something went wrong !!";

	private static final String DANGER="danger";

	private static final String SUCCESS="success";
	
	private static final String REDIRECT="redirect:/admin/{qId}/viewQuery";


	SimpleDateFormat dateFor=new SimpleDateFormat("yyyy-mm-dd hh:mm a");
	Date date=new Date();

	@ModelAttribute
	public void getCurrentEmployee(Model m,Principal p) {
		String name = p.getName();

		Employee employee = this.employeeService.getEmployeeByEmail(name);

		log.info("from common data {}",employee);

		m.addAttribute("emp", employee);

	}

	@GetMapping("/addQuery")
	public String fireQuery(Model m)
	{
		m.addAttribute(QUERY, new Questions());

		return "admin/addQuery";

	}

	@PostMapping("/saveQuery")
	public String addquerytoDb(@Valid @ModelAttribute("query") Questions queries,BindingResult result,Model m,HttpSession session,Principal p)
	{
		try {
			if(result.hasErrors())
			{

				m.addAttribute(QUERY,"queries");
				log.warn("error occured {}",result);
				return "admin/addQuery";
			}

			String name=p.getName();
			Employee employee = employeeService.getEmployeeByEmail(name);

			employee.getQuestions().add(queries);
			queries.setEmp(employee);
			queries.setDate(dateFor.format(date));

			this.employeeService.saveEmp(employee);

			m.addAttribute(QUERY,queries);

			m.addAttribute("emp", employee);
			log.info("query Added : {} ", queries);
			session.setAttribute(MESSAGE, new Message("your Query Added successfilly ! ", SUCCESS));


		}catch (Exception e) {

			e.printStackTrace();
			log.error("Exception occured");

			session.setAttribute(MESSAGE, new Message("query is alredy exist ! ",DANGER));
		}
		return "redirect:/admin/addQuery";

	}


	@GetMapping("/{qId}/viewQuery")
	public String viewQuery(@PathVariable("qId") int qId,Model m)
	{
		Questions question = questionService.findById(qId);
		Employee qemp = question.getEmp();
		List<Answers> answers = question.getAnswers();

		m.addAttribute(QUERY, question);
		m.addAttribute("qemp", qemp);
		m.addAttribute("solve", answers);

		return "admin/viewQuery";
	}

	@GetMapping("/{qId}/reply")
	public String replyToQuery(@PathVariable("qId") int qId,@ModelAttribute("ans") Answers ans,Model m) {

		Questions question = questionService.findById(qId);

		Employee employee = question.getEmp();

		m.addAttribute(QUERY, question);
		m.addAttribute("qemp", employee);
		m.addAttribute("ans", new Answers());

		return "admin/reply";

	}

	@PostMapping("/{qId}/saveReply")
	public String saveReply( @Valid  @PathVariable("qId") int qId,@ModelAttribute("ans") Answers ans,BindingResult result,
			HttpSession session,Model m,Principal p) {

		try {

			if(result.hasErrors())
			{
				log.warn("error occured {} ",result);

				m.addAttribute("ans", new Answers());

				return "redirect:/admin/{qId}/reply";
			}

			String name=p.getName();
			Employee employee = employeeService.getEmployeeByEmail(name);

			Questions question = questionService.findById(qId);
			Employee emp2 = question.getEmp();

			ans.setDate(dateFor.format(date));
			answerService.saveAnswer(ans);
			question.getAnswers().add(ans);
			ans.setEmp(employee);
			ans.setQuestion(question);
			employeeService.saveEmp(employee);

			String subject=" from DSRS";
			String content=""
					+ "<div class='card' style='border:1px solid #e2e2e2; padding:20px'>"
					+ "<p>"
					+ "your quey : "
					+"<div style='color: red'>"
					+question.getQuestion()
					+"</div>"
					+"<br>"
					+" answered by "

					+employee.getEmail()
					+"<br>"
					+ans.getAnswer()

					+ "</p>"
					+ "</div>";
			String to = emp2.getEmail();

			emailService.sendEmail(subject,content,to);

			log.info("response os recorded {}",ans);

			session.setAttribute(MESSAGE, new Message("your response is added Successfully !!",SUCCESS));


		}
		catch (Exception e) {
			log.error("Exception occured");

			session.setAttribute(MESSAGE, new Message(WRONG,DANGER));

		}

		return "redirect:/admin/{qId}/reply";

	}


	@GetMapping("/{aId}/{qId}/viewSolution")
	public String viewSolutions(@PathVariable("aId") int aId, @PathVariable("qId") int qId,Model m) {

		Answers answer = answerService.getAnswerById(aId);
		Employee aemp = answer.getEmp();

		Questions question = questionService.findById(qId);
		Employee qemp = question.getEmp();

		m.addAttribute(QUERY, question);
		m.addAttribute("qemp", qemp);
		m.addAttribute("ans", answer);
		m.addAttribute("aemp", aemp);

		return "admin/viewSolution";


	}





	@GetMapping("/{aId}/{qId}/deleteSolution")
	public String deleteAnswer(@PathVariable("aId") int aId, @PathVariable("qId") int qId,HttpSession session,Principal p) {
		try {
			String name=p.getName();
			Employee employee = employeeService.getEmployeeByEmail(name);

			Questions question = questionService.findById(qId);

			Answers answer = answerService.getAnswerById(aId);
			Employee aemp = answer.getEmp();

			if(employee.getId()==aemp.getId() || employee.getRole().equals("ROLE_ADMIN"))
			{
				question.getAnswers().remove(answer);

				questionService.saveQuestion(question);
				answerService.deleteAnswer(answer);

				session.setAttribute(MESSAGE, new Message(" response  deleted Successfully !!",SUCCESS));

				return REDIRECT;
			}
			else
			{
				session.setAttribute(MESSAGE, new Message(DELETE,DANGER));
				log.warn(DELETE );
			}
		}
		catch (Exception e) {
			log.error("Exception occured");
		}
		return "redirect:/admin/{aId}/{qId}/viewSolution";

	}



	@GetMapping("/{qId}/deleteQuery")

	public String deleteYourQuery(@PathVariable("qId") int qId,Principal p,HttpSession session) {
		try {
			String name=p.getName();
			Employee employee = employeeService.getEmployeeByEmail(name);

			Questions question = questionService.findById(qId);

			Employee qemp = question.getEmp();
			List<Answers> answers = question.getAnswers();

			if(employee.getId()==qemp.getId() || employee.getRole().equals("ROLE_ADMIN"))
			{

				if(answers.isEmpty())
				{

					qemp.getQuestions().remove(question);
					employeeService.saveEmp(qemp);
					session.setAttribute(MESSAGE, new Message(" query  deleted Successfully !!",SUCCESS));
					log.info("your query is deleted ");
					return "redirect:/admin/index/0";
				}
				else {
					log.warn(DELETE );
					session.setAttribute(MESSAGE, new Message(DELETE,DANGER));
				}
			}

			else {
				log.warn(DELETE );
				session.setAttribute(MESSAGE, new Message(DELETE,DANGER));
			}

		}catch (Exception e) {
			log.error("exception occured");
			session.setAttribute(MESSAGE, new Message(DELETE,DANGER));

		}
		return REDIRECT;

	}




	@GetMapping("/{qId}/updateQueryForm")
	public String updateQueryForm(@PathVariable("qId") int qId ,Model m,HttpSession session,Principal p) {

		Questions question = questionService.findById(qId);
		Employee qemp = question.getEmp();

		String name=p.getName();
		Employee employee = employeeService.getEmployeeByEmail(name);

		m.addAttribute(QUERY, question);
		List<Answers> answers = question.getAnswers();

		try {
			if(answers.isEmpty() && employee.getId()==qemp.getId())
			{

				return "admin/updateQuery";

			}

		}catch (Exception e) {
			log.error("Exception occured");
		}
		session.setAttribute(MESSAGE, new Message("your cant't update it now ! ",DANGER));

		return REDIRECT;

	}


	@RequestMapping("/{qId}/updateQuery")
	public String updateQuerytoDb(@Valid @ModelAttribute("query") Questions query,BindingResult result,@PathVariable int qId ,Model m,HttpSession session,Principal p)
	{
		try {
			if(result.hasErrors())
			{
				m.addAttribute(QUERY, new Questions());
				log.warn("error occured {}",result);

			}

			String name=p.getName();
			
			Employee employee = employeeService.getEmployeeByEmail(name);
		
	        employee.getQuestions().add(query);
			query.setEmp(employee);
			query.setDate(dateFor.format(date));
			this.employeeService.saveEmp(employee);
			questionService.updateQuestion(query);
			session.setAttribute(MESSAGE, new Message("your Query updated successfilly ! ", SUCCESS));

			m.addAttribute(QUERY,query);

			m.addAttribute("emp", employee);

			log.info("query Added : {}",query);

		}catch (Exception e) {

			e.printStackTrace();
			log.error("Exception occured");

			session.setAttribute(MESSAGE, new Message("query is alredy exist ! ", DANGER));
		}
		return "admin/updateQuery";

	}
	
	@GetMapping("/unResolve")
	public String unResolvedQueries(Model m,HttpSession session) {
		try {
			
			List<Questions> list = questionService.getAllQuestions();
			List<Questions>qList=new ArrayList<>();
			for(Questions quest:list) {
				List<Answers>answers=quest.getAnswers();
				if(answers.isEmpty()) {
					qList.add(quest);
				}
			}
			
			if(qList.isEmpty()) {
				session.setAttribute(MESSAGE, new Message("there is no UnResolved Queries", SUCCESS));
			}
			m.addAttribute("qlist", qList);
		} 
		catch (Exception e)
		{
			log.error(e.getMessage());
		}
		
		return "admin/unResolved";
	}


}
