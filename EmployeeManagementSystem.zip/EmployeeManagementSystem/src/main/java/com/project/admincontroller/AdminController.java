package com.project.admincontroller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.project.entity.Employee;
import com.project.entity.Message;
import com.project.entity.Questions;
import com.project.service.EmailService;
import com.project.service.EmployeeService;
import com.project.service.QuestionService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private QuestionService questionService;
	
	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private EmailService emailService;
	
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
static Logger log=LoggerFactory.getLogger(AdminController.class);




private static String DLIST="dlist";
private static String MESSAGE="message";
private static String SUCCESS="success";
private static String DANGER="danger";


List<String>designationList=Arrays.asList("","Associate Software Engineer","Software Engineer",
	                                    "Associate Engineer Technology","Engineer Technology","lead Consultant",
	                                    "Train Engineer","Engineer IT","Associate Architect Engineer","Architect Engineer","others");


@ModelAttribute
public void getCurrentEmployee(Model m,Principal p) {
	String name = p.getName();
	
	Employee employee = this.employeeService.getEmployeeByEmail(name);
	
	m.addAttribute("emp", employee);
	m.addAttribute("dlist", designationList);
}


	@RequestMapping("/index/{pageNo}")
	public String dashboard(Model m , @PathVariable("pageNo") int pageNo) {
		try {
			m.addAttribute("title", "user-Dashboard");
			
			int items=5;
			Page<Questions> page=questionService.findPaginated(pageNo, items);
			List<Questions> questions=page.getContent();
			m.addAttribute("qlist", questions);
		} 
		catch (Exception e) {
			log.error(e.getMessage());
		}
		
		return "admin/index";
	}
	
	
	@GetMapping("/empList")
	public String allEmployeesData(Principal p,Model m,HttpSession session) {
	try {
		String name = p.getName();
		Employee emp=employeeService.getEmployeeByEmail(name);
		m.addAttribute("emp",emp);
		
		if(emp.getRole().equals("ROLE_ADMIN")) {
			List<Employee> list=employeeService.getAllEmployesData();
			m.addAttribute("empList",list);
			return "admin/empList";
		}
		else
			session.setAttribute(MESSAGE, new Message("this url is unAuthorised ",DANGER));
		
		
	} catch (Exception e) {
		log.error(e.getMessage());
	}	
	
	return "redirect:/admin/index/0";
	}
	
	
	
	@GetMapping("/profile")
	public String yourProfile(Model m) {

		
		return "admin/profile";

	}
	
	@GetMapping("/editprofile/{id}")
	public String editProfile(@PathVariable("id") int id,Model m) {

		return "admin/editprofile";

	}
	
	
	@PostMapping(value = "/saveprofile")
	public String registerUser(@Valid  @ModelAttribute("emp") Employee emp ,BindingResult result,@RequestParam("profileImage") MultipartFile file,
			Model m,HttpSession session) {
		
		try {

			if(result.hasErrors()) {
				log.warn("error {}",result);
				m.addAttribute("emp",emp);
				m.addAttribute(DLIST,designationList);
				
			return "admin/editprofile";
				
			}
			if(!file.isEmpty()) {

				File deleteFile = new ClassPathResource("static/img").getFile();
				File file1 = new File(deleteFile, emp.getProfile());
			
				
				boolean delete = file1.delete();
				
				log.info("is old file is deleted {}",delete);


				File saveFile = new ClassPathResource("static/img").getFile();

				Path path = Paths.get(saveFile.getAbsolutePath()+File.separator+file.getOriginalFilename());

				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				emp.setProfile(file.getOriginalFilename());
				log.info("img is uploaded");

			}
			else {

				emp.setProfile(emp.getProfile());

			}
			log.info("Saved Employee {}",emp.getPassword());
			
			
			//emp.setPassword(passwordEncoder.encode(emp.getPassword()));
			
			
			 this.employeeService.saveEmp(emp);
			
			m.addAttribute("emp", new Employee());
			
			session.setAttribute(MESSAGE, new Message("updated successfilly ! ", SUCCESS));
		
	
		} catch (Exception e) {
			

			e.printStackTrace();
			m.addAttribute("emp",emp);
			m.addAttribute(DLIST,designationList);
			
			session.setAttribute(MESSAGE, new Message("some thing went wrong! "+e.getMessage(), DANGER));
		}
		
		return "redirect:/admin/profile";
			
	}
	
	
	@GetMapping("/yourQueries")
	public String viewYourQueries(Model m,Principal p) {
		
         String name = p.getName();
		
		Employee employee = this.employeeService.getEmployeeByEmail(name);
		List<Questions> questions = employee.getQuestions();
		
		m.addAttribute("qlist", questions);
		
		return "admin/yourQueries";
		
	}
	
	

	@RequestMapping("/settings")
	public String  settingsTab() {
		return "admin/setting";

	}

	//change password

	@PostMapping("/change-Password")
	public String changePassword(@RequestParam("oldPassword") String oldPassword,@RequestParam("newPassword") String newPassword,Principal principal,HttpSession session) {
		log.info("password {}", oldPassword);
		log.info("password {}", newPassword);
		String name = principal.getName();
		Employee employee = this.employeeService.getEmployeeByEmail(name);
		
		
		
		if(this.passwordEncoder.matches(oldPassword, employee.getPassword()))
		{
			if(oldPassword.equals(newPassword)) {
				
				session.setAttribute(MESSAGE,new  Message("Set the different Password doesn't used in previously..", DANGER));
				return "redirect:/admin/settings";
			}
			employee.setPassword(this.passwordEncoder.encode(newPassword));
			this.employeeService.saveEmp(employee);
			session.setAttribute(MESSAGE,  new  Message("password changed Successfully", SUCCESS));
		}

		else {
			session.setAttribute(MESSAGE,new  Message("Incorrect  Password", DANGER));
			return "redirect:/admin/settings";
		}

		return "redirect:/admin/index/0";
		}
	
	
	
	
	@RequestMapping("/block/{id}")
	public String blockEmployee(@PathVariable("id") int id,HttpSession session) {
		
		try {
			Employee employee = this.employeeService.getEmployeeByID(id);
			employee.setRole("BLOCK");
			this.employeeService.saveEmp(employee);
			String subject="from DSRS";
			String message=""
					+ "<div class='card' style='border:1px solid #e2e2e2; padding:20px'>"
					+"<p> your id"
					+employee.getEmail()
					+" was blocked by Admin </p>"
					+ "</div>";
			
			String to=employee.getEmail();
					
		 this.emailService.sendEmail(subject, message, to);
		 session.setAttribute(MESSAGE,new  Message("you had blocked this id "+employee.getEmail(), DANGER));
				
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "redirect:/admin/empList";
		
	}
	
	
	@RequestMapping("/activate/{id}")
	public String activeEmployee(@PathVariable("id") int id,HttpSession session) {
		
		try {
			Employee employee = this.employeeService.getEmployeeByID(id);
			employee.setRole("ROLE_USER");
			this.employeeService.saveEmp(employee);
			String subject="from DSRS";
			String message=""
					+ "<div class='card' style='border:1px solid #e2e2e2; padding:20px'>"
					+"<p> your id"
					+employee.getEmail()
					+" was activated now you can access this application </p>"
					+ "</div>";
			
			String to=employee.getEmail();
					
		 this.emailService.sendEmail(subject, message, to);
		 session.setAttribute(MESSAGE,new  Message("you activated this id "+employee.getEmail(), SUCCESS));
				
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return "redirect:/admin/empList";
		
	}
	
	
}
