package com.project;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.entity.Employee;
import com.project.repository.EmployeeRepository;
import com.project.service.EmployeeServiceImpl;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class EmployeeServiceTest {

	@InjectMocks
	EmployeeServiceImpl employeeService;
	
	@Mock
	EmployeeRepository employeeRepository;
	
	
	@Before
	void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void registerEmpTest() {
		Employee employee = new Employee(1,"rafi","mahammad","ROLE_USER","test@gmail.com",
				"2023-09-12","Male","563896324560","testing","password");
		employeeService.saveEmp(employee);
		verify(employeeRepository,times(1)).save(employee);
	}
	
	@Test
	public void getEmployeeByEmail() {
		when(employeeRepository.getEmployeebyemail("test@gmail.com")).
		thenReturn(new Employee(1,"rafi","mahammad","ROLE_USER","test@gmail.com",
				"2023-09-12","Male","563896324560","testing","password"));
		Employee emp = employeeService.getEmployeeByEmail("test@gmail.com");
		
		assertEquals("rafi", emp.getFirstName());
		assertEquals("mahammad", emp.getLastName());
		assertEquals("test@gmail.com", emp.getEmail());
	}
	
	
	
}
