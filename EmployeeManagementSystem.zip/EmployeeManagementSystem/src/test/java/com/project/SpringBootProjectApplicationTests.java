package com.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.project.entity.Employee;
import com.project.repository.EmployeeRepository;
import com.project.service.EmployeeServiceImpl;


@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class SpringBootProjectApplicationTests {

//	@Test
//	void contextLoads() {
//	}
	
	@Autowired
	EmployeeServiceImpl service;
	
	@MockBean
	EmployeeRepository repository;
	
	
	@Test
	public void getAllUsersTest() {
		
		Employee emp1 = new Employee(1,"rafi","mahammad","ROLE_USER","test@gmail.com",
				"2023-09-12","Male","563896324560","testing","password");
		Employee emp2 = new Employee(13,"test","eng","ROLE_USER","test2@gmail.com",
				"2023-09-12","Male","563896324560","testcode","password1");
		Employee emp3 = new Employee(14,"test1","eng1","ROLE_USER","test4@gmail.com",
				"2023-09-12","Male","563896324560","testcode","password1");
		List< Employee>emplist=new ArrayList<>();
		emplist.add(emp1);
		emplist.add(emp2);
		emplist.add(emp3);
		when(repository.getEmployesData()).thenReturn(emplist);
		assertEquals(3, service.getAllEmployesData().size());
		
//		verify(repository,times(1)).getEmployesData();
		
	}
	
}
